import React, { useContext, useEffect } from "react";
import "../pages/Home/Home.css";
import { useNavigate } from "react-router-dom";
import Image from "../Image/Image";
import { authContext } from "../Context/AuthContext";

const Navbar = () => {
  const { data, loading, error, setData } = useContext(authContext);
  const navigate = useNavigate();
  useEffect(()=>{
   
    if(data && data.data){
      setData(data)   
    }
   
  }, [])
  const isAuthenticated = localStorage.getItem("auth") !== null;
  const handleLogout = () => {
    localStorage.removeItem("auth");
    setData({}); 
    navigate("/login");
  };

  return (
    <header className="home-header">
      <div className="header-content">
        <div className="header-left">
          <h1 className="home-title" onClick={() => navigate("/")}>
            Welcome to Book Haven
          </h1>
          <p className="home-subtitle">
            Explore your favorite books, anytime, anywhere.
          </p>
        </div>

        <div className="header-right">
          <div className="profile-container">
            <Image
              src={data?.data?.userRecord?.image}
              alt="Profile"
              className="profile-image"
            />
            <div className="profile-dropdown">
              <button className="profile-name">
                {data?.data?.userRecord.email} ▼
              </button>
              <div className="dropdown-menu">
                <button onClick={handleLogout} className="logout-button">
                  {isAuthenticated ? "Logout" : "Login"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
