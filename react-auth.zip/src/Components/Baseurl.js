// export const BaseURL = "https://mern-auth-server-1-5uk7.onrender.com/api/v1" 
export const BaseURL = "http://localhost:5000/api/v1"
export let token = localStorage.getItem("auth")
